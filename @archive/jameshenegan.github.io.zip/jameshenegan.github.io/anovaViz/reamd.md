# Data Inputs
Number of Treatments
Number of Replicates per Treatment
Variance
Mean of Each Treatment

# Create Observed Data
{ "treatment" : j,
  "actualMean" : am,
  "data" : [y0, y1, y2]
}

# Summarize Data
Compute Group Means
Compute Global Mean

# Create Summary Data
{ "group" : j,
  "actualMean" : am,
  "data" : [y0, y1, y2],
  "groupMean": om
}

# Prep data for Viz
## Initial Scatter Plot
Assign x values

{
  "x":
  "y":
  "group":
}


# Adding the grand mean line
# with lines from indivual points
# to grand mean line

# Adding the group mean lines
# with lines from indivual points
# to the group mean lines

# Converting the individual points
# To grouped points
# while adding a grand mean line
# and adding lines from the grouped points
# to the grand mean line



