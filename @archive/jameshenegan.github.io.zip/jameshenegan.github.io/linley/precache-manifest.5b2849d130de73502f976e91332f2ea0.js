self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7b21af6fe44c6242ab68fab8f49e66bc",
    "url": "/index.html"
  },
  {
    "revision": "d89b747343826ea60035",
    "url": "/static/css/2.36020323.chunk.css"
  },
  {
    "revision": "d4c2a668826786d49263",
    "url": "/static/css/main.5ecd60fb.chunk.css"
  },
  {
    "revision": "d89b747343826ea60035",
    "url": "/static/js/2.7317a3cc.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.7317a3cc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d4c2a668826786d49263",
    "url": "/static/js/main.1b53cfa2.chunk.js"
  },
  {
    "revision": "4ec2f90c08f2fa33dc5f",
    "url": "/static/js/runtime-main.0ab85cf8.js"
  },
  {
    "revision": "fc68cc813a24746f89f2485db7e5f2d0",
    "url": "/static/media/01.fc68cc81.mp3"
  },
  {
    "revision": "7b522aa54c8d3157e9bcd57863e90fb0",
    "url": "/static/media/02.7b522aa5.mp3"
  },
  {
    "revision": "ee1490a3fdfecfacd0947f01cbaa9eaa",
    "url": "/static/media/03.ee1490a3.mp3"
  },
  {
    "revision": "0a6941f76c48c9234dfa4b9e1e8cc6f8",
    "url": "/static/media/04.0a6941f7.mp3"
  }
]);